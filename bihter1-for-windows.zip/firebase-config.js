// Firebase Configuration
// Bu dosyayı Firebase Console'dan alacağınız config bilgileriyle güncelleyin

export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "bihtercafemenu.web.app",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};


